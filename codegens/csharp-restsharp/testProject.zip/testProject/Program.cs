using System;
using RestSharp;
namespace HelloWorldApplication {
  class HelloWorld {
    static void Main(string[] args) {
      var client = new RestClient("https://httpbin.org/redirect-to?url=https://postman-echo.com/get");
      client.Timeout = -1;
      var request = new RestRequest(Method.GET);
      IRestResponse response = client.Execute(request);
      Console.WriteLine(response.Content);
    }
  }
}
